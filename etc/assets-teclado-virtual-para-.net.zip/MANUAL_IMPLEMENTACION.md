# Manual de Implementación: Teclado Virtual Inteligente para .NET MVC

Este manual detalla los pasos necesarios para integrar el componente de teclado virtual flotante en un proyecto de **Visual Studio .NET 8 MVC**.

---

## 1. Estructura de Archivos

Copia los archivos del componente a la carpeta `wwwroot` de tu proyecto de Visual Studio:

1.  **JavaScript**: Copia `virtual-keyboard.js` a `wwwroot/js/`.
2.  **CSS**: Copia `virtual-keyboard.css` a `wwwroot/css/`.

---

## 2. Integración Global (Layout)

Para que el teclado esté disponible en todas las vistas de tu aplicación, debes referenciarlo en tu archivo de diseño principal, usualmente ubicado en `Views/Shared/_Layout.cshtml`.

### Paso A: Agregar los Estilos
Dentro de la etiqueta `<head>`, agrega la referencia al CSS:

```html
<link rel="stylesheet" href="~/css/virtual-keyboard.css" asp-append-version="true" />
```

### Paso B: Agregar el Script
Al final del `<body>`, justo antes de cerrar la etiqueta, agrega la referencia al JS:

```html
<script src="~/js/virtual-keyboard.js" asp-append-version="true"></script>
```

---

## 3. Uso en las Vistas (.cshtml)

El teclado se activa automáticamente mediante clases CSS. No necesitas escribir código JavaScript adicional en tus vistas.

### A. Teclado Alfanumérico (Texto estándar)
Se activa agregando la clase `jsteclado`.
```html
<div class="form-group">
    <label>Nombre de Usuario</label>
    <input type="text" class="form-control jsteclado" name="Username" />
</div>
```

### B. Teclado Decimal (Números con punto)
Se activa agregando las clases `jsteclado jsdecimal`.
```html
<div class="form-group">
    <label>Precio Unitario</label>
    <input type="text" class="form-control jsteclado jsdecimal" name="Price" />
</div>
```

### C. Teclado de Enteros (Solo números)
Se activa agregando las clases `jsteclado jsinteger`.
```html
<div class="form-group">
    <label>Cantidad</label>
    <input type="text" class="form-control jsteclado jsinteger" name="Quantity" />
</div>
```

### D. Áreas de Texto (Textarea)
También es compatible con áreas de texto grandes.
```html
<div class="form-group">
    <label>Observaciones</label>
    <textarea class="form-control jsteclado" name="Notes"></textarea>
</div>
```

---

## 4. Características Principales

*   **Flotante y Arrastrable**: El usuario puede mover el teclado por la pantalla arrastrándolo desde la barra superior si este obstruye la vista del input.
*   **Detección Automática**: El teclado identifica el tipo de input y ajusta su diseño (Alfanumérico, Decimal o Entero).
*   **Validación Integrada**: 
    *   En modo `jsdecimal`, solo permite un punto decimal.
    *   En modo `jsinteger`, bloquea el punto decimal y el espacio.
*   **Compatibilidad Táctil**: Funciona tanto con mouse en escritorio como con toques en dispositivos móviles/tabletas.

---

## 5. Personalización Visual

Puedes ajustar los colores y el tamaño editando las variables en la parte superior del archivo `virtual-keyboard.css`:

```css
:root {
    --vk-bg: rgba(23, 23, 23, 0.95); /* Color de fondo */
    --vk-accent: #2563eb;           /* Color del botón Enter */
    --vk-border: #404040;           /* Color de los bordes */
}
```

---

## 6. Solución de Problemas

*   **El teclado no aparece**: Asegúrate de que el input tenga la clase `jsteclado` escrita correctamente.
*   **El teclado tapa el input**: El teclado es arrastrable. Haz clic y arrastra desde la barra superior para moverlo.
*   **Conflictos de Z-Index**: Si el teclado queda detrás de un modal de Bootstrap, aumenta el valor de `z-index` en el archivo `.css` (actualmente es `9999`).

---
*Manual generado para integración en .NET MVC - Abril 2026*
