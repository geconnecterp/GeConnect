import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Delete, X, ArrowUp, CornerDownLeft, Space } from 'lucide-react';

type KeyboardType = 'alphanumeric' | 'numeric';

export const VirtualKeyboard: React.FC = () => {
  const [activeInput, setActiveInput] = useState<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const [keyboardType, setKeyboardType] = useState<KeyboardType>('alphanumeric');
  const [isShift, setIsShift] = useState(false);
  const keyboardRef = useRef<HTMLDivElement>(null);

  const handleFocus = useCallback((e: FocusEvent) => {
    const target = e.target as HTMLInputElement | HTMLTextAreaElement;
    if (target.classList.contains('jsteclado')) {
      setActiveInput(target);
      
      // Determine keyboard type
      const type = target.getAttribute('type') || 'text';
      const inputMode = target.getAttribute('inputmode');
      const isDecimal = target.classList.contains('jsdecimal');
      
      if (type === 'number' || type === 'tel' || inputMode === 'numeric' || inputMode === 'decimal' || isDecimal) {
        setKeyboardType('numeric');
      } else {
        setKeyboardType('alphanumeric');
      }
    }
  }, []);

  const handleBlur = useCallback((e: FocusEvent) => {
    // We use a small timeout to check if the new focus is the keyboard itself
    setTimeout(() => {
      if (document.activeElement && keyboardRef.current?.contains(document.activeElement)) {
        return;
      }
    }, 100);
  }, []);

  useEffect(() => {
    document.addEventListener('focusin', handleFocus);
    return () => document.removeEventListener('focusin', handleFocus);
  }, [handleFocus]);

  const handleKeyPress = (key: string) => {
    if (!activeInput) return;

    const isNumberInput = activeInput.type === 'number';
    const isDecimalInput = activeInput.classList.contains('jsdecimal') || activeInput.getAttribute('inputmode') === 'decimal' || isNumberInput;
    
    let start: number;
    let end: number;

    // selectionStart/End are not supported for type="number" in some browsers
    try {
      start = activeInput.selectionStart ?? activeInput.value.length;
      end = activeInput.selectionEnd ?? activeInput.value.length;
    } catch (e) {
      start = activeInput.value.length;
      end = activeInput.value.length;
    }

    const value = activeInput.value;
    let newValue = '';
    let newCursorPos = start;

    if (key === 'BACKSPACE') {
      if (start === end) {
        if (start > 0) {
          newValue = value.substring(0, start - 1) + value.substring(end);
          newCursorPos = start - 1;
        } else {
          newValue = value;
          newCursorPos = 0;
        }
      } else {
        newValue = value.substring(0, start) + value.substring(end);
        newCursorPos = start;
      }
    } else if (key === '.') {
      // Prevent multiple dots if it's a decimal input
      if (isDecimalInput && value.includes('.')) return;
      
      newValue = value.substring(0, start) + '.' + value.substring(end);
      newCursorPos = start + 1;
    } else if (key === 'ENTER') {
      if (activeInput.tagName === 'TEXTAREA') {
        newValue = value.substring(0, start) + '\n' + value.substring(end);
        newCursorPos = start + 1;
      } else {
        activeInput.blur();
        setActiveInput(null);
        return;
      }
    } else if (key === 'SPACE') {
      newValue = value.substring(0, start) + ' ' + value.substring(end);
      newCursorPos = start + 1;
    } else {
      const char = isShift ? key.toUpperCase() : key.toLowerCase();
      newValue = value.substring(0, start) + char + value.substring(end);
      newCursorPos = start + 1;
    }

    activeInput.value = newValue;
    
    if (!isNumberInput) {
      try {
        activeInput.setSelectionRange(newCursorPos, newCursorPos);
      } catch (e) {
        // Ignore if not supported
      }
    }
    
    activeInput.focus();
    
    // Trigger input event for frameworks like React/Vue to detect change
    activeInput.dispatchEvent(new Event('input', { bubbles: true }));
  };

  const alphanumericLayout = [
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ñ'],
    ['SHIFT', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BACKSPACE'],
    ['SPACE', 'ENTER']
  ];

  const numericLayout = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['.', '0', 'BACKSPACE'],
    ['ENTER']
  ];

  if (!activeInput) return null;

  return (
    <AnimatePresence>
      <motion.div
        ref={keyboardRef}
        drag
        dragMomentum={false}
        dragTransition={{ bounceStiffness: 600, bounceDamping: 20 }}
        initial={{ y: 100, x: '-50%', opacity: 0 }}
        animate={{ y: 0, x: '-50%', opacity: 1 }}
        exit={{ y: 100, x: '-50%', opacity: 0 }}
        className="fixed bottom-10 left-1/2 z-50 bg-neutral-900/95 backdrop-blur-md border border-neutral-700 p-4 rounded-2xl shadow-2xl touch-none w-[95vw] max-w-lg"
        onMouseDown={(e) => e.preventDefault()}
      >
        <div className="flex flex-col">
          {/* Drag Handle & Header */}
          <div className="flex flex-col items-center mb-4 cursor-grab active:cursor-grabbing group">
            <div className="w-12 h-1.5 bg-neutral-700 rounded-full mb-3 group-hover:bg-neutral-600 transition-colors" />
            <div className="flex justify-between items-center w-full px-2">
              <span className="text-neutral-400 text-[10px] font-mono uppercase tracking-widest">
                {keyboardType === 'numeric' ? 'Teclado Numérico' : 'Teclado Alfanumérico'}
              </span>
              <button 
                onClick={() => setActiveInput(null)}
                className="p-1.5 hover:bg-neutral-800 rounded-full transition-colors text-neutral-400 hover:text-white pointer-events-auto"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-2 pointer-events-auto">
            {(keyboardType === 'numeric' ? numericLayout : alphanumericLayout).map((row, rowIndex) => (
              <div key={rowIndex} className="flex justify-center gap-1 w-full">
                {row.map((key) => {
                  const isSpecial = ['SHIFT', 'BACKSPACE', 'ENTER', 'SPACE'].includes(key);
                  
                  let content: React.ReactNode = key;
                  let buttonClass = "h-11 md:h-12 flex items-center justify-center rounded-lg font-medium transition-all active:scale-95 select-none text-sm ";
                  
                  if (key === 'SHIFT') {
                    content = <ArrowUp size={18} className={isShift ? "text-blue-400" : ""} />;
                    buttonClass += `w-12 ${isShift ? 'bg-neutral-700 border-blue-500/50' : 'bg-neutral-800'} border border-neutral-700`;
                  } else if (key === 'BACKSPACE') {
                    content = <Delete size={18} />;
                    buttonClass += "w-12 bg-neutral-800 border border-neutral-700 text-red-400";
                  } else if (key === 'ENTER') {
                    content = <CornerDownLeft size={18} />;
                    buttonClass += "flex-1 bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-900/20";
                  } else if (key === 'SPACE') {
                    content = <Space size={18} />;
                    buttonClass += "flex-[3] bg-neutral-800 border border-neutral-700";
                  } else {
                    buttonClass += "w-8 md:w-10 bg-neutral-800 border border-neutral-700 text-neutral-200 hover:bg-neutral-700";
                    content = isShift ? key.toUpperCase() : key.toLowerCase();
                  }

                  return (
                    <button
                      key={key}
                      onClick={() => {
                        if (key === 'SHIFT') setIsShift(!isShift);
                        else handleKeyPress(key);
                      }}
                      className={buttonClass}
                    >
                      {content}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
