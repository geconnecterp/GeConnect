/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VirtualKeyboard } from './components/VirtualKeyboard';

export default function App() {
  return (
    <div className="min-h-screen bg-neutral-50 p-8 font-sans text-neutral-900">
      <div className="max-w-md mx-auto space-y-12 pt-12">
        <header className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tight text-neutral-900">Teclado Digital</h1>
          <p className="text-neutral-500">Haz clic en los campos con la clase <code className="bg-neutral-200 px-1 rounded text-neutral-700">jsteclado</code> para activar el teclado virtual.</p>
        </header>

        <main className="space-y-8">
          <section className="space-y-4 bg-white p-6 rounded-2xl shadow-sm border border-neutral-200">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-neutral-400">Formulario de Prueba</h2>
            
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-neutral-700">Nombre Completo (Alfanumérico)</label>
                <input 
                  type="text" 
                  className="jsteclado w-full px-4 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ej: Juan Pérez"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-neutral-700">Edad (Numérico)</label>
                <input 
                  type="number" 
                  className="jsteclado w-full px-4 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ej: 25"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-neutral-700">Teléfono (Numérico)</label>
                <input 
                  type="tel" 
                  className="jsteclado w-full px-4 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ej: 555-0123"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-neutral-700">Precio (Texto con clase jsdecimal)</label>
                <input 
                  type="text" 
                  className="jsteclado jsdecimal w-full px-4 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ej: 99.99"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-neutral-700">Mensaje (Alfanumérico)</label>
                <textarea 
                  className="jsteclado w-full px-4 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all min-h-[100px]"
                  placeholder="Escribe algo aquí..."
                />
              </div>
            </div>
          </section>

          <section className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
            <h3 className="text-blue-800 font-semibold mb-2">Instrucciones</h3>
            <ul className="text-sm text-blue-700 space-y-2 list-disc list-inside">
              <li>Usa la clase <code className="font-mono bg-blue-100 px-1 rounded">jsteclado</code> en cualquier input.</li>
              <li>El teclado detecta automáticamente si el input es numérico o de texto.</li>
              <li>Funciona con inputs de tipo <code className="font-mono">text</code>, <code className="font-mono">number</code>, <code className="font-mono">tel</code> y <code className="font-mono">textarea</code>.</li>
            </ul>
          </section>
        </main>
      </div>

      <VirtualKeyboard />
    </div>
  );
}

